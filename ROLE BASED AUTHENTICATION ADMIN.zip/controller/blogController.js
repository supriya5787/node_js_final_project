

exports.blogsidebar = (req,res)=>{
    res.render('blog-sidebar');
}

exports.blogsingle = (req,res)=>{
    res.render('blog-single');
}