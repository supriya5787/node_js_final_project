exports.service = (req,res)=>{
    res.render('service');
}