exports.contact = (req,res)=>{
    res.render('contact');
}

