exports.doctor = (req,res)=>{
    res.render('doctor');
}

exports.doctorsingle = (req,res)=>{
    res.render('department-single');
}


exports.appoinment = (req,res)=>{
    res.render('appoinment');
}