exports.department = (req,res)=>{
    res.render('department');
}

exports.departmentsingle = (req,res)=>{
    res.render('department-single');
}